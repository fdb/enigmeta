This is a template project that contains everything you need to get started with a new HTML 5 project.

Some useful links
=================
* HTML 5 Course: http://www.w3schools.com/html5/
* CSS Course: http://www.w3schools.com/css/